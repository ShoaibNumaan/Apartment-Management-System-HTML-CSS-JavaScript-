<?php

session_start();

global $choice; 

if(isset($_POST['insert']))
{
 	global $choice; 
 	$choice = "insert";
}


if(isset($_POST['show']))
{
	global $choice;
	$choice = "Show";
}


if(isset($_POST['avms']))
{
	global $choice;
	$choice = "avms";
}

switch($choice)
{
	case "insert": header("location:Insert.html");
				   break;
	
				   break;
	case "Show"	 : header("location:Show.html");		   
				   break;
				   
	case "avms"	 : header("location:avms/index.php");		   
				   break;
				  
}


?>